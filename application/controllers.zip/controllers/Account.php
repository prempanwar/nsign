<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {



	public function __construct(){

        parent::__construct();
        //$this->load->model('common_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('cart');
        if(user_logged_in()===FALSE){
			redirect(base_url());
		}
    }


	public function index(){
		$user_id = user_id();
		if($this->input->post()) {
			$data = $this->input->post();
			$this->crud->updateData('users', $data, array('user_id' => $user_id));
			echo json_encode(array('status' => 'success', 'message' => 'Profile updated successfully'));
			exit;
		}
		$data['data'] = $this->crud->readData('*', 'users', array('user_id' => $user_id))->row_array();
		$data['title'] = "Home";
		$data['council'] = $this->crud->readData('*', 'council')->result();
		$data['template'] = 'frontend/account/dashboard';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function order_history(){
		$data['title'] = "Order History";
		$data['template'] = 'frontend/account/order_history';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function change_password(){
		$data['title'] = "Change Password";
		$data['template'] = 'frontend/account/change_password';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function logout() {
		// $this->session->unset_userdata('user_info');
		$this->session->sess_destroy();
		redirect(base_url());
	}



} 