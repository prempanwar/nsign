<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {



	public function __construct(){

        parent::__construct();
        //$this->load->model('common_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('cart');
    }

	private function _check_login(){
		if(user_logged_in()===FALSE){
			redirect(base_url());
		}
    }



	public function index(){
		$data['title'] = "Home";
		$data['council'] = $this->crud->readData('*', 'council')->result();
		$data['template'] = 'frontend/index';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function get_council() {
		$council_id = $this->input->post('council_id');
		$road_symbol = $this->input->post('road_symbol');
		$street_name = $this->input->post('street_name');
		$logo = base_url("assets/backend/uploads/council-logo/logo-3.png");
		$road_symbol_logo = base_url("assets/backend/uploads/council-logo/Road-symbol.png");
		$border = 1;
		$width = 100;
		$data = $this->crud->readData('*', 'council', array('council_id' => $council_id))->row_array();
		if($data['zipcode'] == 0)
			$data['zipcode'] = '';
		if($data['border'] > 0) {
			$border = $data['border'];
		}
		if($road_symbol == 1) {
			$width = $width - 18;
		}
		if($data['logo'] != '') {
			$width = $width - 18;
		}
		$html = '<div class="plate-bg" id="plate-'.$border.'"><div class="left-poll menuitem"></div> <div class="right-poll menuitem"></div>';
		if($data['logo'] != '') {
			$html .= '<div class="left">
                <img src="'.base_url($data['logo']).'" class="img-responsive">
            </div>';
		}
            
        $html .= '<div class="middle" style="width:'.$width.'%">
                <h1 style="font-family:'.$data['font'].';">'.$street_name.'</h1>
            </div>';
        if($road_symbol == 1) {
        	$html .= '<div class="right">
                <img src="'.$road_symbol_logo.'" class="img-responsive">
                <div class="right-bottom">
                  L 25
                </div>
            </div>';
        }

            
        $html .= '</div>';
        // echo $html;
        echo json_encode(array('html' => $html, 'zipcode' => $data['zipcode']));
	}

	public function about_us(){
		$data['title'] = "About Us";
		$data['template'] = 'frontend/about-us';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function contact(){
		$data['title'] = "Contact Us";
		$data['template'] = 'frontend/contact';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function login(){
		if(user_logged_in() == true) redirect(base_url('account'));		
		$data['title'] = "login";
		$data['template'] = 'frontend/login';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function login_submit(){
		$this->load->library('encryption');
		$error = '';
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == TRUE) {
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$data = $this->crud->readData('user_id, user_role, name, email, password', 'users', array('email' => $email))->row_array();
			if($data) {
				if($password == $this->encryption->decrypt($data['password'])) {
					$user_data = array(
						'id' 			=> $data['user_id'],
						'user_role' 	=> $data['user_role'],
						'user_name' 	=> $data['name'],
						'email'			=> $data['email'],
						'logged_in'     => TRUE
					);
					$this->session->unset_userdata('user_info');
					$this->session->set_userdata('user_info',$user_data);
					$this->session->set_flashdata('success', 'Login successfully.');
					echo json_encode(array('status' => 'success', 'message' => 'Login successfully'));
				}
				else {
					echo json_encode(array('status' => 'error', 'message' => 'Invalid password'));
				}
			}
			else {
				echo json_encode(array('status' => 'error', 'message' => 'This email is not exist in out database'));
			}
        }
        else {
        	echo json_encode(array('status' => 'error', 'message' => validation_errors()));
        }
	}

	public function register_submit(){
		$this->load->library('encryption');
		$this->form_validation->set_rules('name', 'Full name', 'required|max_length[50]');
        $this->form_validation->set_rules('email', 'Email', 'required|is_unique[users.email]');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required|numeric');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]|max_length[10]');
        $this->form_validation->set_rules('confirm', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() == TRUE) {
			$data = $this->input->post();
			unset($data['confirm']);
			$data['password'] = $this->encryption->encrypt($data['password']);
			$this->crud->createData('users', $data);
			echo json_encode(array('status' => 'success', 'message' => 'Register successfully.'));
        }
        else {
        	echo json_encode(array('status' => 'error', 'message' => validation_errors()));
        }
	}

	public function not_found(){
		$this->output->set_status_header('404');
		$data['title'] = "Demo";
		$data['template'] = 'frontend/404';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function logout() {
		// $this->session->unset_userdata('user_info');
		$this->session->sess_destroy();
		redirect(base_url());
	}

	public function cart(){
		// if(user_logged_in() == true) redirect(base_url('account'));		
		$data['title'] = "Cart";
		$data['template'] = 'frontend/cart';
		$this->load->view('templates/frontend/frontend_template', $data);
	}

	public function add_to_cart() {
		$desc = $this->input->post('desc');
		$council = $this->input->post('council');
		$council_name = $this->input->post('council_name');
		$price = $this->input->post('price');
		$data = array(
	        'id'      => $council,
	        'qty'     => 1,
	        'price'   => $price,
	        'name'    => $council_name,
	        'options' => array('desc' => $desc)
		);

		$this->cart->insert($data);
		echo json_encode(array('status' => 'success', 'message' => 'Product added to cart'));
	}

	public function update_cart() {
		$data = $this->input->post();
		$this->cart->update($data);
		echo json_encode(array('status' => 'success', 'message' => 'Cart updated successfully.'));
	}

	public function checkout() {
		$data['title'] = "Checkout";
		$data['template'] = 'frontend/checkout';
		$this->load->view('templates/frontend/frontend_template', $data);
	}



} 