<div class="check-out" id="check-out-form">
    <div class="container">
        <!--         <h1 class="heading-1">CHECKOUT</h1> -->
        <div class="row">
            <form method="post" action="">
                <div class="col-xs-12 col-sm-6 col-sm-6">
                    <div class="left-checkout">
                        <h3>Personal Information</h3>
                        <div class="col-xs-4 col-sm-3 label"><label>Full Name</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Email</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="email" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Mobile No.</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Billing Address</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>City</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>State</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group">
                            <select class="form-control">
                                <option>Select State</option>
                                <option>Select State</option>
                                <option>Select State</option>
                                <option>Select State</option>
                                <option>Select State</option>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Country</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group">
                            <select class="form-control">
                                <option>Select Country</option>
                                <option>Select Country</option>
                                <option>Select Country</option>
                                <option>Select Country</option>
                                <option>Select Country</option>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Pin</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <br><br>
                        <h3>Shipping Address</h3>
                        <div class="col-xs-4 col-sm-3 label"><label>Address</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>City</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>State</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group">
                            <select class="form-control">
                                <option>Select State</option>
                                <option>Select State</option>
                                <option>Select State</option>
                                <option>Select State</option>
                                <option>Select State</option>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Country</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group">
                            <select class="form-control">
                                <option>Select Country</option>
                                <option>Select Country</option>
                                <option>Select Country</option>
                                <option>Select Country</option>
                                <option>Select Country</option>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Pin</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>
                            <button class="btn-2">Submit</button>
                            </label>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-sm-6">
                    <div class="right-checkout" id="payment-method">
                        <h3>Payment Method</h3>
                        <img src="images/visa-card.png" width="50px" class="card">
                        <img src="images/master-card.jpg" width="50px" class="card">
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Payment Mode</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group">
                            <label class="radio-inline">
                            <input type="radio" name="optradio" checked>Credit Card
                            </label>
                            <label class="radio-inline">
                            <input type="radio" name="optradio">Debit Card
                            </label>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Card Number</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Expire Date</label></div>
                        <div class="col-xs-8 col-sm-9 label-value form-group"><input type="text" name="name" class="form-control" required=""></div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>Card Details</label></div>
                        <div class="col-xs-8 col-sm-3 label-value form-group">
                            <input type="text" name="name" class="form-control" required="" placeholder="MM/YY">
                        </div>
                        <div class="col-xs-8 col-sm-3 label-value form-group">
                            <input type="text" name="name" class="form-control" required="" placeholder="CVV">
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-xs-4 col-sm-3 label"><label>
                            <button class="btn-2">Submit</button>
                            </label>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>