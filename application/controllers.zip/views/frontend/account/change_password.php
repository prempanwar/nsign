<div class="clearfix"></div>
<section>
    <div class="user">
        <div class="container">
            <div class="row">
                <?php $this->load->view('frontend/account/left_bar'); ?>
                <div class="col-xs-12 col-sm-9 right">
                    <div class="tab-content">
                        <div id="Change-Password" class="tab-pane fade in active">
                            <h3>Change Password</h3>
                            <form class="" action="/action_page.php">
                                <div class="col-xs-12 col-sm-6 form-group">
                                    <label class="control-label " for="pwd">Old Password</label>
                                    <input type="password" class="form-control" id="pwd" placeholder="Enter password" required="">
                                </div>
                                <div class="col-xs-12 col-sm-6 form-group">
                                    <label class="control-label" for="pwd">New Password</label>
                                    <input type="password" class="form-control" id="pwd" placeholder="New password" required="">
                                </div>
                                <div class="col-xs-12 col-sm-6 form-group">
                                    <label class="control-label" for="pwd">Confirm Password</label>
                                    <input type="password" class="form-control" id="pwd" placeholder="Confirm password" required="">
                                </div>
                                <div class="col-xs-12 col-sm-6 form-group"> 
                                    <label class="control-label" for="pwd"></label>
                                    <button type="submit" class="btn btn-2">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>