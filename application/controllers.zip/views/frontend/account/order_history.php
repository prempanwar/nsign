<div class="clearfix"></div>
<section>
    <div class="user">
        <div class="container">
            <div class="row">
                <?php $this->load->view('frontend/account/left_bar'); ?>
                <div class="col-xs-12 col-sm-9 right">
                    <div class="tab-content">
                        <div id="Order-Details" class="tab-pane fade in active">
                            <h3>Order Details</h3>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Council Name</th>
                                            <th>Council Price</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Madhya Pradesh</td>
                                            <td>$250/-</td>
                                            <td>20/10/2018</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>