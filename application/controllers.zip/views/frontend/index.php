<section>
    <div class="banner">
        <!-- <img src="images/banner-5-1.jpg" class="img-responsive" alt="Banner" title="Banner"> -->
        <div class="container">
            <div class="row">
                <form>
                    <div class="col-xs-12 col-sm-12 left">
                        <div class="inner-left">
                            <!-- <img src="images/frame-2.png" class="img-responsive"> -->
                            <div class="forms-div">
                                <div class="price hidden-xs hidden-sm hidden-md hidden-lg">
                                    <label>Price</label> :- <span> <strong>$ 25</strong></span>
                                </div>
                                <select name="type" id="council_select">
                                    <option value="" selected="">Select Council Name</option>
                                    <?php
                                    foreach ($council as $row) {
                                      ?>
                                      <option value="<?= $row->council_id; ?>"><?= $row->name; ?></option>
                                      <?php
                                    }
                                    ?>
                                </select>
                                <div class="clearfix"></div>
                            </div>
                            <div class="bottom-div" id="council" style="display: none;">
                                <div class="col-xs-12 col-sm-6 left-side">
                                    <div class="form-group">
                                        <label>Do You Require Road Symbol ?</label><br>
                                        <input type="radio" name="road_symbol" onchange="get_council();" value="1" class="post_wall road-symbol"> &nbsp;&nbsp; Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name="road_symbol" onchange="get_council();" value="0" class="post_wall road-symbol-no"> &nbsp;&nbsp; No
                                    </div>
                                    <div class="form-group" id="post-wall" style="display: none;">
                                        <label>Do You Require Post Mount or Wall Mount ?</label><br>
                                        <input type="radio" name="mount" class="Mount_click img-1" value="post"> &nbsp;&nbsp; Wall Mount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name="mount" class="Mount_click img-2" value="wall"> &nbsp;&nbsp; Post Mount
                                    </div>
                                    <div class="form-group" id="post-code" style="display: none;">
                                        <label>Do You Require Post Code ?</label><br>
                                        <input type="radio" name="gender" value="male" class="form-control post_code aa"> &nbsp;&nbsp; Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name="gender" value="female" class="form-control post_code bb"> &nbsp;&nbsp; No
                                        <div class="" id="post_textbox">
                                            <input type="text" name="street-name" class="form-control" placeholder="Post Code" id="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Do you want double side ?</label><br>
                                        <input type="radio" name="double_side" onchange="price_cal();" value="1" class="post_wall road-symbol"> &nbsp;&nbsp; Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name="double_side" onchange="price_cal();" value="0" class="post_wall road-symbol-no"> &nbsp;&nbsp; No
                                    </div>
                                    <div id="street-name" style="display: none1">
                                        <div class="form-group" id="street-name" >
                                            <label>Street Name</label><br>
                                            <input type="text" name="street_name" maxlength="40" class="form-control" placeholder="Type Street Name">
                                        </div>
                                        <div class="form-group" style="margin-bottom: 0px;">
                                            <input type="button" onclick="add_to_cart();" name="street-name" class="form-control" placeholder="Type Street Name" required="" value="Add to Cart">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 right-side">
                                    <!-- <div class="plate-bg" id="plate-1">
                                        <div class="left">
                                            <img src="<?= base_url("assets/backend/uploads/council-logo/logo-3.png"); ?>" class="img-responsive">
                                        </div>
                                        <div class="middle">
                                            <h1>Abhishek Indriya</h1>
                                        </div>

                                        <div class="right">
                                            <img src="<?= base_url("assets/backend/uploads/council-logo/Road-symbol.png"); ?>" class="img-responsive">
                                            <div class="right-bottom">
                                              L 25
                                            </div>
                                        </div>
                                    </div>


                                    <div class="plate-bg" id="plate-2">
                                        <div class="left">
                                            <img src="<?= base_url("assets/backend/uploads/council-logo/logo-3.png"); ?>" class="img-responsive">
                                        </div>

                                        <div class="middle">
                                            <h1>Abhishek Indriya</h1>
                                        </div>

                                        <div class="right">
                                            <img src="<?= base_url("assets/backend/uploads/council-logo/Road-symbol.png"); ?>" class="img-responsive">
                                            <div class="right-bottom">
                                              L 25
                                            </div>
                                        </div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!--<div class="col-xs-12 col-sm-12 right">
            <div class="inner-right">
              <div class="img-cont">
                <img src="images/frame-2.png" class="img-responsive" />
              </div>
              <div class="amout">
                 <sapn></span> 25
              </div>
            </div>
            </div> -->
    </div>
</section>
<div class="clearfix"></div>
<section>
    <div class="about">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h1 class="heading-1">About Us</h1>
                    <p>At N-Sign Ltd we manufacture street nameplates to any local
                        authority specification, although we have our standard format
                        that covers the majority of local authorities. Our service offers
                        both wall mounted plates and free-standing plates. We also
                        produce other signs at our factory (such as road sign-age, and
                        site signs) we have geared our production for street
                        nameplates
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="clearfix"></div>
<section>
    <div class="about name-plates wow fadeInDown">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h1 class="heading-1">Our Street Name Plates</h1>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <p>Our sign trays are made from polycarbonate; the tray is
                        fastened to two stainless steel posts with our vandal proof
                        system. The face panels are reverse lettered on anti-glare
                        polycarbonate, which is fitted into the tray using our own
                        integral clip system and VHB tape.
                    </p>
                    <p>
                        The plates have been tested in high vandalism areas and
                        we have ‘put it through the mill’ and have had no
                        problems. We can also produce any logo on our plates (for
                        example council emblem). The signs are available at 1120
                        x 150mm and 1120 x 285mm.
                        TYPE YOUR STREET NAME HERE
                        Street Name Plates
                        Home Name Plates About us Contact us Long in/Register
                        Add to Basket
                        Contact
                    </p>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <img src="<?= base_url("assets/frontend/images/img-1.png"); ?>" class="img-responsive">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ------------------------ Start Div 2 ------------------------ -->
<section>
    <div class="div-2">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4 item">
                </div>
                <div class="col-xs-12 col-sm-4 item">
                </div>
                <div class="col-xs-12 col-sm-4 item">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ------------------------ End Div 2 -------------------------- -->
<script type="text/javascript">
    var show_post_code = '';
    $(function () {
        $(".post_wall").click(function () {
            if ($(this).is(":checked")) {
                $("#post-wall").show(500);
            } else {
                $("#post-wall").hide();
            }
        });
    });
    
    
    $(function () {
        $(".Mount_click").click(function () {
            if($(this).val() == 'wall') {
                $('.menuitem').addClass("menuitemshow");
            }
            else {
                $('.menuitem').removeClass("menuitemshow");
            }
            if(show_post_code) {
                if ($(this).is(":checked")) {
                    $("#post-code").show(500);
                } else {
                    $("#post-code").hide();
                }
            }
        });
    });
    
    
    // Post Code
    $(function () {
      $(".post_code").click(function () {
          if ($(this).is(":checked")) {
              $("#street-name").show(500);                      
          }
      });
    });
    
    $(function () {
      $(".bb").click(function () {
          if ($(this).is(":checked")) {
              $("#post_textbox").hide(500);
          }
      });
    });
    
    $(function () {
      $(".aa").click(function () {
          if ($(this).is(":checked")) {
              $("#post_textbox").show(500);
          }
      });
    });
    // Post Code
</script>
<script type="text/javascript">
    $(function () {
      $(".img-1").click(function () {
          if ($(this).is(":checked")) {
              $("#img_id_1").hide(500);
              $("#img_id_2").hide(500);
              $("#img_id_4").hide(500);
          }
      });
    });
    
    
    $(function () {
      $(".img-2").click(function () {
          if ($(this).is(":checked")) {
            $("#img_id_4").show(500);
            $("#img_id_2").hide(500);
            $("#img_id_1").hide();
          }
      });
    });
    
    
    // For Road Symbol
    $(function () {
      $(".road-symbol").click(function () {
          if ($(this).is(":checked")) {
              $("#img_id_1").hide(500);
              $("#img_id_2").hide(500);
              $("#img_id_4").hide(500);
          }
      });
    });
    
    
    $(function () {
      $(".road-symbol-no").click(function () {
          if ($(this).is(":checked")) {
            $("#img_id_1").show(500);
            $("#img_id_2").hide();
            $("#img_id_4").hide();
          }
      });
    });
    // For Road Symbol
    
    
    var price = 85;
    $(function () {
        $('#price').hide();
        $('#council').hide();
        $('#council_select').change(function () {
            if($(this).val() == '') {
                $(".price").addClass('hidden-lg');
                $('#council').hide();
            }
            else {
                $(".price").removeClass('hidden-lg');
                $('#council').show();
            }
            get_council();
        });
    });
    function get_council() {
        var council = $("#council_select").val();
        var road_symbol = $("input[name='road_symbol']:checked").val();
        var street_name = $("input[name=street_name]").val();
        $.ajax({
            type: "post",
            data: "council_id="+council+"&road_symbol="+road_symbol+"&street_name="+street_name,
            url: BASE_URL+"pages/get_council",
            dataType: "json",
            success: function(result){
                $(".right-side").html(result.html);
                show_post_code = result.zipcode;
                if(result.zipcode == '') {
                    $("#post-code").hide();
                }
                price_cal();
            }
        });
    }
    function price_cal() {
        price = 85;
        var double_side = $("input[name='double_side']:checked").val();
        var road_symbol = $("input[name='road_symbol']:checked").val();
        if(road_symbol == '1') {
            price = price + 5;
        }
        if(double_side == 1) {
            price = 150
        }
        $(".price span strong").html('$ '+price);
        // get_council();
    }
    $("input[name=street_name]").keyup(function(){
        var name = $(this).val();
        $(".right-side .middle h1").html(name);
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('input.post_wall[type="radio"]').click(function(){
            var inputValue = $(this).attr("value");
            $("." + inputValue).toggle();
        });
    });
    
    
    $(function () {
      $(".chkPassport").click(function () {
          if ($(this).is(":checked")) {
              $("#dvPassport").show(500);
              //$("#AddPassport").hide();
          } else {
              $("#dvPassport").hide();
              //$("#AddPassport").show();
          }
      });
    });
</script>
<script type="text/javascript">
    function add_to_cart() {
        var desc = $(".right-side").html();
        var council = $("#council_select").val();
        var council_name = $("#council_select option:selected").text();
        $.ajax({
            type: "post",
            data: "desc="+desc+"&council="+council+"&council_name="+council_name+"&price="+price,
            url: BASE_URL+"pages/add_to_cart",
            dataType: "json",
            success: function(output){
                // $("#div1").html(result);
                toasterMessage(output.status, output.message);
            }
        });
    }
</script>
<style type="text/css">
    .wall_mounts, .post_mounts{
        position: relative;
        width: 200px;
        /*        height: 120px;*/
    }
    .left-poll.menuitemshow::before{
        content: '';
        position: absolute;
        height: 10px;
        width: 20px;
        top: -10px;
        left: 13%;
        background-color: #000;
        z-index: 0;
    }
    .left-poll.menuitemshow::after {
        content: '';
        position: absolute;
        height: 26px;
        width: 20px;
        bottom: -22px;
        left: 13%;
        background-color: #000;
        z-index: 0;
    }
    .right-poll.menuitemshow::before{
        content: '';
        position: absolute;
        height: 10px;
        width: 20px;
        top: -10px;
        right: 13%;
        background-color: #000;
        z-index: 0;
    }
    .right-poll.menuitemshow::after {
        content: '';
        position: absolute;
        height: 26px;
        width: 20px;
        bottom: -22px;
        right: 13%;
        background-color: #000;
        z-index: 0;
    }
</style>