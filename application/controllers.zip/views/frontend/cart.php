<section>
    <div class="cart-page">
        <div class="container">
            <?php
            if($this->cart->contents()) {
                ?>
                <div class="row">
                    <h1 class="heading-1 text-center">CART</h1>
                    <div class="head-sec">
                        <div class="col-xs-6 col-sm-6">Council Image</div>
                        <div class="col-xs-6 col-sm-3">Council Name</div>
                        <div class="col-xs-6 col-sm-1">Price</div>
                        <div class="col-xs-6 col-sm-1">Quantity</div>
                        <div class="col-xs-6 col-sm-1"></div>
                    </div>
                    <?php echo form_open(base_url('pages/update_cart'), 'id="cartForm"'); ?>
                        <?php $i = 1; ?> 
                        <?php foreach ($this->cart->contents() as $items): ?>
                            <?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
                                <div class="bottom-sec">
                                    <div class="col-xs-6 col-sm-6">
                                        <?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
                                            <?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
                                                <?php echo $option_value; ?><br />
                                            <?php endforeach; ?>
                                                
                                        <?php endif; ?>
                                        <!-- <img src="images/plate-1.png" alt=""> -->
                                    </div>
                                    <div class="col-xs-6 col-sm-3"><?= ucfirst($items['name']); ?></div>
                                    <div class="col-xs-6 col-sm-1">$<?php echo $this->cart->format_number($items['price']); ?></div>
                                    <div class="col-xs-6 col-sm-1"><?php echo form_input(array('name' => $i.'[qty]', 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5', 'class' => 'form-control')); ?></div>
                                    <div class="col-xs-6 col-sm-1"><i class="fa fa-trash"></i></div>
                                </div>
                        <?php $i++; ?> 
                        <?php endforeach; ?>
                        <?php echo form_submit('', 'Update your Cart'); ?>
                    <?php echo form_close(); ?>
                    <a class="btn btn-primary" href="<?= base_url('checkout'); ?>">Proceed to checkout</a>
                </div>
                <?php
            }
            else {
                ?>
                <div class="row text-center">
                    <h1 class="heading-1 text-center">CART</h1>
                    <p>No product in cart</p>
                    <a style="color: blue;" href="<?= base_url(); ?>">Click here to add product</a>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</section>
<script type="text/javascript">
    $( "#cartForm").submit(function( event ) {
        // event.preventDefault();
        var POSTURL = $(this).attr('action');
        var $profile = $('#cartForm');
        $.ajax({
            type: 'POST',
            url: POSTURL,
            data: new FormData($($profile)[0]),
            contentType: false,
            cache: false,
            processData:false,
            dataType: "json",
            beforeSend: function (result) {
                $('.loader-wrap').removeClass('dn');
            },
            complete: function () {
                $('.loader-wrap').addClass('dn');
            },
            success: function (output) {
                toasterMessage(output.status, output.message);
            },
            error: function (error) {
                toasterMessage('error', 'Something went wrong please try again');
            }
        });
        event.preventDefault();
    });
</script>
<style type="text/css">
    .plate-bg{
        height: 118px;
        width: 495px;
    }
</style>