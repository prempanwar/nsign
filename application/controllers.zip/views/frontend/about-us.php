<div class="clearfix"></div>
<section>
    <div class="about name-plates wow fadeInDown about-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <h1 class="heading-1">About Us</h1>
                    <p>N Sign Ltd is a rapidly expanding signage and engraving company established in 2000. We are able to offer a wide range of different signage and engraving solutions.</p>
                    <p>In 2007, N Sign took over Stockton Engraving Company and moved its premises from Middlesbrough to Stockton. We have since relocated again, moving into the former Portrack Conservative Club, a 10,000sq ft premises on Maritime Road, Stockton.</p>
                    <p>The business’ diverse signage portfolio includes work such as shop fronts and site signs, through to vehicle graphics and wraps. We offer a complete service from initial site survey through to design, manufacture and installation.</p>
                    <p>In 2006 N Sign moved away from the traditional steel street nameplate when they developed their own a unique recycled and recyclable polycarbonate street nameplate. These are supplied to local authorities across the UK, including Darlington, Middlesbrough, Redcar and Cleveland, Hartlepool, Hambleton and Basildon.</p>
                    <p>The take over of Stockton Engraving in 2007 saw N Sign inherit a well-established team of engravers, experienced in everything from personalized items to industrial engraving. The services include anything from labels and control panels to trophy and gift engraving into a variety of different materials, such as stainless steel, brass, laminate and acrylics.</p>
                    <!-- <ul class="primary-list">
                        <li><i class="fa fa-check-square"></i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </li>
                        <li><i class="fa fa-check-square"></i>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
                        <li><i class="fa fa-check-square"></i>Lorem Ipsum is simply dummy text of the printing and </li>
                        <li><i class="fa fa-check-square"></i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum </li>
                        </ul>
                        <br><br>
                        <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        </p> -->
                </div>
                <div class="col-xs-12 col-sm-6">
                    <img src="<?= base_url("assets/frontend/images/img-1.png"); ?>" class="img-responsive">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ------------------------ Start Div 2 ------------------------ -->
<section>
    <div class="div-2">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4 item">
                </div>
                <div class="col-xs-12 col-sm-4 item">
                </div>
                <div class="col-xs-12 col-sm-4 item">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ------------------------ End Div 2 -------------------------- -->