<script>
    $( function() {
        $("#council").addClass("active treeview");
        $('#example').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        } );
    } );
</script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><i class="fa fa-arrow-circle-o-right"></i> Edit Council</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url("admin/home"); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <!-- <li><a href="#">Forms</a></li> -->
            <li class="active">Edit Council</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <?php echo $this->session->flashdata('success_msg'); ?> 

            <div class="col-xs-12">
                <div class="nav-tabs-custom">
                    <!-- <ul class="nav nav-tabs">
                        <li class="active"><a href="#list" data-toggle="tab" aria-expanded="true">All Council</a></li>
                         <li class=""><a href="#add" data-toggle="tab" aria-expanded="false">Add Council</a></li> 
                    </ul> -->
                    <div class="tab-content">
                        <form class="form-horizontal" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="field-1" class="col-sm-4 control-label">Council Name</label>
                                <label for="field-1" class="col-sm-4 control-label">Plate Design</label>
                                <label for="field-1" class="col-sm-4 control-label">Logo</label>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-4">
                                    <input class="form-control" name="name" type="text" value="<?= $council['name']; ?>" required="">
                                </div>
                                <div class="col-sm-4">
                                    <select class="form-control" name="border" type="text" required="">
                                        <option value="">Select Border</option>
                                        <option value="1" <?php if($council['border'] == 1) echo "selected"; ?>>Rectangle</option>
                                        <option value="2" <?php if($council['border'] == 2) echo "selected"; ?>>Square</option>
                                    </select>
                                </div>
                                <div class="col-sm-4">
                                    <input class="btn btn-block" style="background: #efefef;" name="file" type="file">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="field-1" class="col-sm-4 control-label">Zipcode</label>
                                <label for="field-1" class="col-sm-4 control-label">Font</label>
                                <label for="field-1" class="col-sm-4 control-label">Commission(%)</label>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-4">
                                    <select class="form-control" name="zipcode" type="text" required="">
                                        <option value="">Select Zipcode</option>
                                        <option value="1" <?php if($council['zipcode'] == '1') echo "selected"; ?>>Yes</option>
                                        <option value="0" <?php if($council['zipcode'] == '0') echo "selected"; ?>>No</option>
                                    </select>
                                </div>
                                <div class="col-sm-4">
                                    <select class="form-control" name="font" type="text" required="">
                                        <option value="">Select Font</option>
                                        <option value="'Roboto', sans-serif" <?php if($council['font'] == "'Roboto', sans-serif") echo "selected"; ?>>Roboto</option>
                                        <option value="'Poppins', sans-serif" <?php if($council['font'] == "'Poppins', sans-serif") echo "selected"; ?>>Poppins</option>
                                        <option value="'Lato', sans-serif" <?php if($council['font'] == "'Lato', sans-serif") echo "selected"; ?>>Lato</option>
                                        <option value="'Open Sans', sans-serif" <?php if($council['font'] == "'Open Sans', sans-serif") echo "selected"; ?>>Open Sans</option>
                                        <option value="'Noto Sans', sans-serif" <?php if($council['font'] == "'Noto Sans', sans-serif") echo "selected"; ?>>Noto Sans</option>
                                        <option value="'Montserrat', sans-serif" <?php if($council['font'] == "'Montserrat', sans-serif") echo "selected"; ?>>Montserrat</option>
                                    </select>
                                </div>
                                <div class="col-sm-4">
                                    <input class="form-control" name="commission" type="text" value="<?= $council['commission']; ?>" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-1 col-sm-5">
                                    <button type="submit" class="btn btn-info">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
            <!-- left column -->
            <div class="col-md-5">
                <!-- Horizontal Form -->         
            </div>
        </div>
        <!--/.col (left) -->
</div>