        <div class="scrollup" style="display: block;"></div>
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-4">
                        <h1>N-Sign Trophies</h1>
                        <p>Mark a special occasion with a trophy from N-Sign.</p>
                        <p>Buy trophies at competitive prices at: 
                            <a href="http://www.trophies.n-sign.co.uk/">http://www.trophies.n-sign.co.uk/</a>
                        </p>
                    </div>
                    <div class="col-xs-12 col-sm-4 text-center">
                        <h1>Contact Us</h1>
                        <p>N-Sign, Sign House, Maritime Road, Stockton-On-Tees, TS18 2EZ.</p>
                        <a href="tel:01642 800 222" style="color: #ffffff;">01642 800 222</a><br>
                        <a href="mailto:enquiries@n-sign.co.uk" style="color: #ffffff;">enquiries@n-sign.co.uk</a>
                    </div>
                    <div class="col-xs-12 col-sm-4 text-right">
                        <h1>Social Links</h1>
                        <ul class="social">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <p class="copy-right">© 2018 N-sign <a href="https://www.n-sign.co.uk/">Designed by Phunky Moo</a></p>
                </div>
            </div>
        </footer>
    </body>
</html>
<style type="text/css">
    .parsley-errors-list li{
        color: red;
    }
    .alert-icon img{
        width: 40px;
    }
</style>