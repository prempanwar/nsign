<?php $this->load->view('templates/backend/backend_header'); ?>
<?php $this->load->view($template); ?>
<?php $this->load->view('templates/backend/backend_footer'); ?>